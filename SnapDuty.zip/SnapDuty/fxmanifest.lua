fx_version 'cerulean'
game 'gta5'

author 'Goober'
description 'SnapDuty - Live Blips & Duty System'
version '2.0.0'

shared_script 'config.lua'

client_scripts {
    'client/*.lua'
}

server_scripts {
  'server/migrations.lua',
  'server/time.lua',
  'server/*.lua'
}
