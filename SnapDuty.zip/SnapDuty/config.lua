Config = {}

Config.RolePermissions = {
    sast = {
        blipIcon = 60,
        blipColor = 29,
        acePerm = "duty.sast",
        webhook = "https://discord.com/api/webhooks/1391877203859603506/8UkZV8-0kK28QXneZYPCNmeBVMLUTJtHJcyJeCarZZgU_LZDFVSwN5FTaBZX8nb05LVE",
        thumbnail = "https://example.com/images/police.png"
    },
    fib = {
        blipIcon = 60,
        blipColor = 40,
        acePerm = "duty.fib",
        webhook = "https://discord.com/api/webhooks/1391878047551983817/jJj2I3g0MmOFWjSEIRHyoGgp3Q7zdWhX84hcSIa2eWr1A_ACTR669sKK8SI0bPSsQxsM",
        thumbnail = "https://example.com/images/police.png"
    },
    k9 = {
        blipIcon = 60,
        blipColor = 27,
        acePerm = "duty.k9",
        webhook = "https://discord.com/api/webhooks/1391878875801190500/XSjHhBi3WHGforEe6OOAWhfERC5tholIY1Q9xS9kIni0-6y1RzbpzXm5n-sc1Cb136A6",
        thumbnail = "https://example.com/images/police.png"
    },
    ambulance = {
        blipIcon = 61,
        blipColor = 8,
        acePerm = "duty.ambulance",
        webhook = "https://discord.com/api/webhooks/1391879080290422915/YfNHm9-Qx3Rl14jrXuzU1vCeNcMHSVh6QhHXLU_jbk56Qz6k1p7hEya3NQGagEQfwCb9",
        thumbnail = "https://example.com/images/ems.png"
    },
    safd = {
        blipIcon = 61,
        blipColor = 1,
        acePerm = "duty.safd",
        webhook = "https://discord.com/api/webhooks/1391964826657493014/-QBmRRL_KHw5bdy3Ai4feXja7K095RB2hdVGCZrNGe_MSvPZxzQS0fk1U0R6jEOB5Xau",
        thumbnail = "https://example.com/images/fire.png"
    },
    staff = {
        blipColor = 0,
        acePerm = "duty.staff",
        webhook = "https://discord.com/api/webhooks/YOUR_STAFF_WEBHOOK",
        thumbnail = "https://example.com/images/staff.png"
    }
}

print("[SnapDuty] config.lua successfully loaded")