if not Config then Config = {} end

local dutyBlips = {}

if not Config.RolePermissions then
    local loadedConfig = LoadResourceFile(GetCurrentResourceName(), "config.lua")
    if loadedConfig then
        local chunk = load(loadedConfig, "config", "t", _G)
        if chunk then
            chunk()
            print("[SnapDuty] Manually loaded config.lua into client environment.")
        else
            print("^1[SnapDuty] Failed to load config.lua chunk on client^7")
        end
    else
        print("^1[SnapDuty] Failed to read config.lua on client!^7")
    end
end

local function roleStyleFor(dept)
    local role = (Config.RolePermissions and Config.RolePermissions[dept or ""]) or {}
    return {
        sprite = role.blipIcon or 1,
        color  = role.blipColor or 1,
        label  = role.displayName or (dept or "PD"),
        scale  = (role.blipScale and tonumber(role.blipScale)) or 0.85,
        short  = role.shortRange ~= nil and role.shortRange or true
    }
end

local function ensureCoordBlip(id, dept, coords, callsign)
    local entry = dutyBlips[id]
    local exists = entry and entry.blip and DoesBlipExist(entry.blip)

    if not exists then
        local style = roleStyleFor(dept)
        local blip = AddBlipForCoord((coords and coords.x) or 0.0, (coords and coords.y) or 0.0, (coords and coords.z) or 0.0)

        SetBlipSprite(blip, style.sprite)
        SetBlipColour(blip, style.color)
        SetBlipScale(blip, style.scale)
        SetBlipAsShortRange(blip, style.short)

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(("[%s] %s"):format(style.label, callsign or tostring(id)))
        EndTextCommandSetBlipName(blip)

        dutyBlips[id] = { blip = blip, dept = dept, callsign = callsign }
        return blip
    else
        -- update dept/callsign metadata if changed
        if dept and entry.dept ~= dept then entry.dept = dept end
        if callsign and entry.callsign ~= callsign then entry.callsign = callsign end
        return entry.blip
    end
end

-- ========== Events from server ==========

RegisterNetEvent("snapduty:addBlip", function(sourceServerId, department, roleConfig)
    local ped = GetPlayerPed(-1)
    TriggerServerEvent("snapduty:requestPosition", sourceServerId)
end)

-- Update an officer's position
RegisterNetEvent("snapduty:updateBlipPosition", function(sourceId, coords, department)
    if not coords or not coords.x then return end
    local entry = dutyBlips[sourceId]
    local blip  = ensureCoordBlip(sourceId, department, coords)
    if blip then
        SetBlipCoords(blip, coords.x + 0.0, coords.y + 0.0, (coords.z or 0.0) + 0.5)
    end
end)

-- Force-create blip
RegisterNetEvent("snapduty:forceCreateBlip", function(sourceId, coords, department, callsign)
    local blip = ensureCoordBlip(sourceId, department, coords, callsign)
    if blip and coords then
        SetBlipCoords(blip, coords.x + 0.0, coords.y + 0.0, (coords.z or 0.0) + 0.5)
    end
end)

RegisterNetEvent("snapduty:removeBlip", function(playerId)
    local entry = dutyBlips[playerId]
    if entry then
        if entry.blip and DoesBlipExist(entry.blip) then
            RemoveBlip(entry.blip)
        end
        dutyBlips[playerId] = nil
    end
end)

CreateThread(function()
    while true do
        for id, entry in pairs(dutyBlips) do
            if not entry.blip or not DoesBlipExist(entry.blip) then
                TriggerServerEvent("snapduty:requestForceCreate", id)
            end
        end
        Wait(5000)
    end
end)

AddEventHandler("onClientResourceStart", function(res)
    if res == GetCurrentResourceName() then
    end
end)

AddEventHandler("playerSpawned", function()
end)
