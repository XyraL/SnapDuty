-- SnapDuty - DB Migrations (auto-runs at resource start)
-- Supports oxmysql (preferred) and mysql-async (fallback)

local USING_OX = (GetResourceState('oxmysql') == 'started')
local DB = {}

if USING_OX then
    DB.exec = function(sql, params, cb)
        exports.oxmysql:execute(sql, params or {}, function(affected)
            if cb then cb(affected) end
        end)
    end
    DB.query = function(sql, params, cb)
        exports.oxmysql:query(sql, params or {}, function(rows)
            if cb then cb(rows or {}) end
        end)
    end
else
    -- mysql-async (MySQL.Async.*)
    DB.exec = function(sql, params, cb)
        MySQL.Async.execute(sql, params or {}, function(affected)
            if cb then cb(affected) end
        end)
    end
    DB.query = function(sql, params, cb)
        MySQL.Async.fetchAll(sql, params or {}, function(rows)
            if cb then cb(rows or {}) end
        end)
    end
end

local TARGET_SCHEMA_VERSION = 1

local function ensureMeta(cb)
    local sql = [[
        CREATE TABLE IF NOT EXISTS snapduty_meta (
            k VARCHAR(50) PRIMARY KEY,
            v VARCHAR(255) NOT NULL
        );
    ]]
    DB.exec(sql, {}, cb)
end

local function getCurrentVersion(cb)
    DB.query("SELECT v FROM snapduty_meta WHERE k = 'schema_version' LIMIT 1;", {}, function(rows)
        local v = tonumber(rows[1] and rows[1].v or 0) or 0
        cb(v)
    end)
end

local function setVersion(v, cb)
    DB.exec([[
        INSERT INTO snapduty_meta (k, v) VALUES ('schema_version', ?)
        ON DUPLICATE KEY UPDATE v = VALUES(v);
    ]], { tostring(v) }, cb)
end

-- === Migration #1: create time-tracking table ===
local function migration_1(cb)
    local sql = [[
        CREATE TABLE IF NOT EXISTS snapduty_time_daily (
            identifier VARCHAR(64) NOT NULL,
            date_key   INT NOT NULL,         -- YYYYMMDD (server local)
            seconds    INT NOT NULL DEFAULT 0,
            PRIMARY KEY (identifier, date_key)
        );
    ]]
    DB.exec(sql, {}, function()
        -- DB.exec("CREATE INDEX IF NOT EXISTS idx_snapduty_time_daily_date ON snapduty_time_daily (date_key);", {}, function()
        setVersion(1, cb)
    end)
end

local function runMigrations(fromVersion, cb)
    local function nextStep(v)
        if v < 1 then
            return migration_1(function() nextStep(1) end)
        end

        if cb then cb() end
    end
    nextStep(fromVersion)
end

local function startMigrations()
    ensureMeta(function()
        getCurrentVersion(function(cur)
            if cur >= TARGET_SCHEMA_VERSION then
                print(("[SnapDuty] DB schema ok (v%d)."):format(cur))
                return
            end
            print(("[SnapDuty] Migrating DB v%d -> v%d..."):format(cur, TARGET_SCHEMA_VERSION))
            runMigrations(cur, function()
                print("[SnapDuty] DB migrations complete.")
            end)
        end)
    end)
end

if USING_OX then
    CreateThread(startMigrations)
else
    if MySQL and MySQL.ready then
        MySQL.ready(startMigrations)
    else
        CreateThread(function()
            Wait(1500)
            startMigrations()
        end)
    end
end
