-- SnapDuty - server.lua (blips + weekly duty time tracking)
-- QBCore + oxmysql / mysql-async compatible

local QBCore = exports['qb-core']:GetCoreObject()
local dutyTracker = {}   -- [src] = { startTime, department, callsign, date, afkPaused }
local afkTracker  = {}   -- [src] = { lastPosition, lastCheck }

if not Config then Config = {} end

-- -----------------------------------------------------------
-- Load role config if missing
-- -----------------------------------------------------------
if not Config.RolePermissions then
    local loadedConfig = LoadResourceFile(GetCurrentResourceName(), "config.lua")
    if loadedConfig then
        local chunk = load(loadedConfig, "config", "t", _G)
        if chunk then
            chunk()
            print("[SnapDuty] Manually loaded config.lua into server environment.")
        else
            print("^1[SnapDuty] Failed to load config.lua chunk!^7")
        end
    else
        print("^1[SnapDuty] Failed to read config.lua file!^7")
    end
end
if not Config.RolePermissions then
    print("^1[SnapDuty] ERROR: Config.RolePermissions is still missing or invalid after load!^7")
    Config.RolePermissions = {}
end

local function isPD(src)
    local info = dutyTracker[src]
    if info and Config.RolePermissions[info.department] then
        return true
    end
    -- Off-duty: allow if they have *any* PD acePerm from config
    for dept, role in pairs(Config.RolePermissions or {}) do
        if role and role.acePerm and IsPlayerAceAllowed(src, role.acePerm) then
            return true
        end
    end
    return false
end

-- -----------------------------------------------------------
-- Embedded Duty-Time Tracker
-- -----------------------------------------------------------
local USING_OXMYSQL = (GetResourceState('oxmysql') == 'started')
local Sessions = {} -- [src] = { id = "identifier", start = os.time() }

-- Prefer QBCore citizenid; fallback to rockstar license
local function getIdentifier(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if Player and Player.PlayerData and Player.PlayerData.citizenid then
        return Player.PlayerData.citizenid
    end
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:find("license:") then return id end
    end
    return GetPlayerIdentifier(src, 0)
end

local function dateKey(ts)
    local d = os.date("*t", ts)
    return (d.year * 10000) + (d.month * 100) + d.day -- YYYYMMDD
end

local function upsertDaily(id, key, addSeconds)
    if not id or addSeconds <= 0 then return end
    if USING_OXMYSQL then
        exports.oxmysql:execute(
            [[INSERT INTO snapduty_time_daily (identifier, date_key, seconds) VALUES (?, ?, ?)
              ON DUPLICATE KEY UPDATE seconds = seconds + VALUES(seconds)]],
            { id, key, addSeconds }
        )
    else
        MySQL.Async.execute(
            [[INSERT INTO snapduty_time_daily (identifier, date_key, seconds) VALUES (@i,@k,@s)
              ON DUPLICATE KEY UPDATE seconds = seconds + @s]],
            { ['@i']=id, ['@k']=key, ['@s']=addSeconds }
        )
    end
end

-- Split elapsed time over midnight boundaries and persist
local function addElapsedToDaily(id, startTs, endTs)
    if not id or not startTs or not endTs or endTs <= startTs then return end
    local cur = startTs
    while cur < endTs do
        local dt  = os.date("*t", cur)
        local eod = os.time({year=dt.year, month=dt.month, day=dt.day, hour=23, min=59, sec=59}) + 1
        local sliceEnd = math.min(eod, endTs)
        upsertDaily(id, dateKey(cur), sliceEnd - cur)
        cur = sliceEnd
    end
end

-- /dutytime request → server sums last 7 days and adds live session
RegisterNetEvent("snapduty:server:requestWeekly", function()
    local src = source
    local id  = getIdentifier(src)

    -- last 7 date_keys (today..today-6)
    local keys = {}
    for i = 0, 6 do keys[#keys+1] = dateKey(os.time() - i*86400) end
    local placeholders = table.concat((function(t) for _=1,#keys do t[#t+1]='?' end; return t end)({}), ',')

    local params = { id }; for _,k in ipairs(keys) do params[#params+1]=k end
    local sql = "SELECT date_key, seconds FROM snapduty_time_daily WHERE identifier = ? AND date_key IN ("..placeholders..")"

    local function respond(rows)
        local map = {}
        for _, r in ipairs(rows or {}) do map[tonumber(r.date_key)] = tonumber(r.seconds) end
        local total = 0
        for _, k in ipairs(keys) do total = total + (map[k] or 0) end
        local sesh = Sessions[src]
        if sesh and sesh.start then total = total + (os.time() - sesh.start) end
        TriggerClientEvent("snapduty:client:weekly", src, { total = total })
    end

    if USING_OXMYSQL then
        exports.oxmysql:query(sql, params, respond)
    else
        MySQL.Async.fetchAll(sql, params, respond)
    end
end)

-- -----------------------------------------------------------
-- /duty [department] [callsign]
-- -----------------------------------------------------------
RegisterCommand("duty", function(source, args)
    if source == nil or source == 0 then
        print("/duty command triggered from console or invalid source:", tostring(source))
        return
    end

    local playerId = source
    local Player = QBCore.Functions.GetPlayer(playerId)
    local playerName = Player and (Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname) or GetPlayerName(playerId)

    if #args == 2 then
        local department = string.lower(args[1])
        local callsign   = args[2]
        local role = Config.RolePermissions[department]

        if not role then
            TriggerClientEvent("chatMessage", playerId, "SnapDuty", {255,0,0}, "Invalid department!")
            return
        end
        if role.acePerm and not IsPlayerAceAllowed(playerId, role.acePerm) then
            TriggerClientEvent("chatMessage", playerId, "SnapDuty", {255,0,0}, "You do not have permission to go on duty for this department!")
            return
        end

        if dutyTracker[playerId] then
            -- Going OFF duty
            local info   = dutyTracker[playerId]
            local dTime  = os.time() - info.startTime

            -- time tracker: persist session
            local sesh = Sessions[playerId]
            if sesh and sesh.start then addElapsedToDaily(sesh.id, sesh.start, os.time()) end
            Sessions[playerId] = nil

            dutyTracker[playerId] = nil
            afkTracker[playerId]  = nil

            sendDiscordEmbed(playerName, info.department, info.callsign, "Off Duty", dTime, info.date)

            -- Remove this officer's blip from other on-duty players
            for _, tgt in pairs(GetPlayers()) do
                local t = tonumber(tgt)
                if t ~= playerId and dutyTracker[t] then
                    TriggerClientEvent("snapduty:removeBlip", t, playerId)
                end
            end
            -- Remove other blips from this officer
            for otherId,_ in pairs(dutyTracker) do
                TriggerClientEvent("snapduty:removeBlip", playerId, otherId)
            end

            TriggerClientEvent("chatMessage", playerId, "SnapDuty", {0,255,0},
                ("You are now off duty! You were on duty for %d seconds."):format(dTime))
        else
            -- Going ON duty
            dutyTracker[playerId] = {
                startTime  = os.time(),
                department = department,
                callsign   = callsign,
                date       = os.date("%Y-%m-%d"),
                afkPaused  = false
            }
            local ped = GetPlayerPed(playerId)
            afkTracker[playerId] = {
                lastPosition = ped and DoesEntityExist(ped) and GetEntityCoords(ped) or vector3(0,0,0),
                lastCheck    = os.time()
            }

            -- time tracker: start live session
            Sessions[playerId] = { id = getIdentifier(playerId), start = os.time() }

            sendDiscordEmbed(playerName, department, callsign, "On Duty", nil, dutyTracker[playerId].date)
            TriggerClientEvent("chatMessage", playerId, "SnapDuty", {0,255,0}, "You are now on duty!")

            -- Show existing on-duty blips to YOU
            for otherId, otherInfo in pairs(dutyTracker) do
                if otherId ~= playerId then
                    local cfg = Config.RolePermissions[otherInfo.department]
                    TriggerClientEvent("snapduty:addBlip", playerId, otherId, otherInfo.department, cfg)
                end
            end
            -- Broadcast YOUR blip to other on-duty players
            for _, tgt in pairs(GetPlayers()) do
                local t = tonumber(tgt)
                if t ~= playerId and dutyTracker[t] then
                    TriggerClientEvent("snapduty:addBlip", t, playerId, department, role)
                end
            end
        end
    else
        -- No args: toggle OFF only
        if dutyTracker[playerId] then
            local info  = dutyTracker[playerId]
            local dTime = os.time() - info.startTime

            -- time tracker: persist session
            local sesh = Sessions[playerId]
            if sesh and sesh.start then addElapsedToDaily(sesh.id, sesh.start, os.time()) end
            Sessions[playerId] = nil

            dutyTracker[playerId] = nil
            afkTracker[playerId]  = nil

            sendDiscordEmbed(playerName, info.department, info.callsign, "Off Duty", dTime, info.date)

            for _, tgt in pairs(GetPlayers()) do
                local t = tonumber(tgt)
                if t ~= playerId and dutyTracker[t] then
                    TriggerClientEvent("snapduty:removeBlip", t, playerId)
                end
            end
            for otherId,_ in pairs(dutyTracker) do
                TriggerClientEvent("snapduty:removeBlip", playerId, otherId)
            end

            TriggerClientEvent("chatMessage", playerId, "SnapDuty", {0,255,0},
                ("You are now off duty! You were on duty for %d seconds."):format(dTime))
        else
            TriggerClientEvent("chatMessage", playerId, "SnapDuty", {255,0,0}, "You are not on duty! Use /duty [department] [callsign].")
        end
    end
end, false)

-- -----------------------------------------------------------
-- Cleanup on disconnect
-- -----------------------------------------------------------
AddEventHandler("playerDropped", function(reason)
    local playerId = source
    local Player   = QBCore.Functions.GetPlayer(playerId)
    local playerName = Player and (Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname) or GetPlayerName(playerId)

    if dutyTracker[playerId] then
        local info  = dutyTracker[playerId]
        local dTime = os.time() - info.startTime

        -- time tracker: persist session up to DC
        local sesh = Sessions[playerId]
        if sesh and sesh.start then addElapsedToDaily(sesh.id, sesh.start, os.time()) end
        Sessions[playerId] = nil

        sendDiscordEmbed(playerName, info.department, info.callsign, "Off Duty (Disconnected)", dTime, info.date, reason)

        dutyTracker[playerId] = nil
        afkTracker[playerId]  = nil

        for _, tgt in pairs(GetPlayers()) do
            local t = tonumber(tgt)
            if t ~= playerId and dutyTracker[t] then
                TriggerClientEvent("snapduty:removeBlip", t, playerId)
            end
        end
        for otherId,_ in pairs(dutyTracker) do
            TriggerClientEvent("snapduty:removeBlip", playerId, otherId)
        end
    end
end)

-- -----------------------------------------------------------
-- Client helpers (blip sync)
-- -----------------------------------------------------------
RegisterNetEvent("snapduty:requestPosition", function(targetId)
    local src = source
    local info = dutyTracker[targetId]
    if not info then return end

    local ped = GetPlayerPed(targetId)
    if ped and DoesEntityExist(ped) then
        local coords  = GetEntityCoords(ped)
        local heading = GetEntityHeading(ped)
        TriggerClientEvent("snapduty:updateBlipPosition", src, targetId,
            { x = coords.x, y = coords.y, z = coords.z, h = heading }, info.department)
    end
end)

RegisterNetEvent("snapduty:requestFullBlip", function(targetId)
    local src  = source
    local info = dutyTracker[targetId]
    if info then
        local ped = GetPlayerPed(targetId)
        if ped and DoesEntityExist(ped) then
            local coords = GetEntityCoords(ped)
            TriggerClientEvent("snapduty:forceCreateBlip", src, targetId,
                { x = coords.x, y = coords.y, z = coords.z }, info.department, info.callsign)
        end
    end
end)

-- Self-heal: client sanity sweep calls this to rebuild a missing blip
RegisterNetEvent("snapduty:requestForceCreate", function(targetId)
    local src  = source
    local info = dutyTracker[targetId]
    if not info then return end
    local ped = GetPlayerPed(targetId)
    if ped and DoesEntityExist(ped) then
        local coords = GetEntityCoords(ped)
        TriggerClientEvent("snapduty:forceCreateBlip", src, targetId,
            { x = coords.x, y = coords.y, z = coords.z }, info.department, info.callsign)
    end
end)

-- -----------------------------------------------------------
-- Discord embed helper
-- -----------------------------------------------------------
function sendDiscordEmbed(playerName, department, callsign, status, duration, date, disconnectReason)
    local roleConfig = Config.RolePermissions[department]
    if not roleConfig or not roleConfig.webhook then return end

    local isOn = (status == "On Duty")
    local color = isOn and 3066993 or 15158332
    local dispDept = department
    local timeNow  = os.date("%I:%M %p")

    local fields = {
        { name = "Officer", value = playerName, inline = true },
        { name = "Callsign", value = callsign or "N/A", inline = true },
        { name = "Department", value = dispDept, inline = true },
        { name = "Date", value = date or os.date("%Y-%m-%d"), inline = true }
    }
    if duration then
        local m = math.floor(duration/60)
        local s = duration % 60
        table.insert(fields, { name = "Duration", value = string.format("%d min %d sec", m, s), inline = false })
    end
    if disconnectReason then
        table.insert(fields, { name = "Disconnect Reason", value = disconnectReason, inline = false })
    end

    local embedData = {{
        title       = playerName .. " - " .. status,
        description = "Duty status update for " .. playerName,
        color       = color,
        fields      = fields,
        footer      = { text = "RDPD Logger • " .. timeNow },
        timestamp   = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        thumbnail   = { url = roleConfig.thumbnail or "" }
    }}

    PerformHttpRequest(roleConfig.webhook, function() end, "POST", json.encode({
        username = "RDPD Logger",
        embeds   = embedData
    }), { ["Content-Type"] = "application/json" })
end

-- -----------------------------------------------------------
-- Position broadcaster
-- -----------------------------------------------------------
CreateThread(function()
    while true do
        Wait(2000)
        for playerId, info in pairs(dutyTracker) do
            local ped = GetPlayerPed(playerId)
            if ped and DoesEntityExist(ped) then
                local coords  = GetEntityCoords(ped)
                local heading = GetEntityHeading(ped)

                -- Large move/teleport → ask viewers to fully recreate blip
                local afk = afkTracker[playerId]
                if afk then
                    local dist = #(coords - afk.lastPosition)
                    if dist > 100.0 then
                        for _, tgt in pairs(GetPlayers()) do
                            local t = tonumber(tgt)
                            if t ~= playerId and dutyTracker[t] then
                                TriggerClientEvent("snapduty:forceCreateBlip", t, playerId,
                                    { x = coords.x, y = coords.y, z = coords.z }, info.department, info.callsign)
                            end
                        end
                    end
                    afk.lastPosition = coords
                    afk.lastCheck    = os.time()
                end

                -- Normal incremental updates (include department + heading)
                for _, tgt in pairs(GetPlayers()) do
                    local t = tonumber(tgt)
                    if t ~= playerId and dutyTracker[t] then
                        TriggerClientEvent("snapduty:updateBlipPosition", t, playerId,
                            { x = coords.x, y = coords.y, z = coords.z, h = heading }, info.department)
                    end
                end
            end
        end
    end
end)
